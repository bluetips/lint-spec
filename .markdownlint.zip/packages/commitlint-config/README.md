# `commitlint-config`

> TODO: description

## Usage

```
const commitlintConfig = require('commitlint-config');

// TODO: DEMONSTRATE API
```
