# `stylelint-config`

> TODO: description

## Usage

```
const stylelintConfig = require('stylelint-config');

// TODO: DEMONSTRATE API
```
