# `markdownlint-config`

> TODO: description

## Usage

```
const markdownlintConfig = require('markdownlint-config');

// TODO: DEMONSTRATE API
```
